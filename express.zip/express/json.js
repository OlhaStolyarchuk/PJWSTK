//curl -X POST http://localhost:3000/jsondata -H "Accept: application/json" -H "Content-type: application/json" -d '{ "name" : "Olya" }'
const express = require('express');
const bodyParser = require('body-parser');

const app = express();
app.set('views', './views');
app.set('view engine', 'pug');
app.use(express.json());
app.use(bodyParser.urlencoded({
    extended: true
}));
app.use(bodyParser.json());

app.listen(3000);
console.log('Server is online.');

app.post('/jsondata', function(req, res) {

    console.log(req.body);
    xs
    //   res.send("Username: "+req.body["name"]+ "\n"+"Index: "+req.body["index"]+"\n"+ "password: "+req.body["password"]);
    // });
    res.render('index', { username: req.body["username"], password: req.body["password"], id: req.body["id"]});
   });







// //curl -d '{"username":"Olya","password":"fjfj","Index":"fwecfw"}' -H "Content-Type: application/json" http://localhost:3000/jsondata '{"username":"Olya","password":"fjfj","Index":"fwecfw"}' -i
// var app = require('express')();
// var bodyParser = require('body-parser');
//
// app.use(bodyParser.json()); // for parsing application/json
//
//
// app.post('/jsondata', function (req, res) {
//   console.log(req.body);
//   res.end();
// });
//
// app.listen(3000);

// var express = require('express')
//   , bodyParser = require('body-parser');
//
// var app = express();
//
// app.use(bodyParser.json());
//
// app.post('/jsondata', function(request, response){
// console.log('request =' + JSON.stringify(request.body))     // your JSON
//    response.send(request.body);    // echo the result back
// });
//
// app.listen(3000);



// var express        =         require("express");
// var bodyParser     =         require("body-parser");
// var app            =         express();
// //app.use(express.bodyParser());
// app.use(bodyParser.urlencoded({ extended: false }));//kiedy extended jest false my nie mozemy wyswietlac(post)zagniezdzony obiekt
// app.use(bodyParser.json());
//
// // app.get('/form', function(req, res) {
// //         res.sendFile(__dirname + "/" + "form_json.html");//The res.sendFile() function sends a file on a specific path. __dirname generates the root directory where the server resides.
// //     });
// app.post('/jsondata', function(req, res){
//        response = {
//            username : req.body.username,
//            password : req.body.password,
//            id: req.body.id
//            };
//
//        //this line is optional and will print the response on the command prompt
//        //It's useful so that we know what infomration is being transferred
//        //using the server
//        console.log(response);
//
//        //convert the response in JSON format
//        res.end(JSON.stringify(response));//tutaj jest convertacja wproadzonych danych do formatu JSON
//    });
//
// app.listen(3000,console.log(`Server is running....`));
// var express    = require('express');
// var bodyParser = require('body-parser');
// var app = express();
//
// app.use(bodyParser.json());
// app.use(bodyParser.urlencoded({ extended: true }));
//
// app.use(function (req, res, next) {
//   console.log('aeee ' +  JSON.stringify(req.body))
//   next()
// })
//
// app.post('/hello', function (req, res) {
//   console.log(JSON.stringify(req.body.hiee) + ' yoooooo');
//   res.send('hello : ' + JSON.stringify(req.body));
// });
//
// app.listen(3000, function () {
//   console.log('Example app listening on port 3000!');
// });
