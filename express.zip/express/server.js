 var express        =         require("express");
 var bodyParser     =         require("body-parser");
 var app            =         express();
 //var ejs = require('ejs');
//app.use(express.bodyParser());//ono zawiera wszystkie te wierszt:app.use(express.json());//app.use(express.urlencoded());//app.use(express.multipart())
//app.set('view engine', 'ejs');
 app.use( bodyParser.json() );
 app.use(express.json());
 app.use(bodyParser.urlencoded({ extended: true }));
 app.set('views', './views');
 app.set('view engine', 'pug');

 //app.use(bodyParser.json());
 app.get('',function(req,res){
 res.sendfile("index.html");

 });
 app.post("/formdate",function(req,res){
 // res.render(`<p> Username: ${req.body.username}<br>
 //   Password: ${req.body.password}<br>
 //   Index: ${req.body.id}<br>
 //    </p>`);

	res.render('index', { username: req.body.username, password: req.body.password, id: req.body.id});

 });
 app.listen(3000,console.log(`Server is running....`));
// var http=require("http");
// var express=require("express");
// var app=express();
// app.use(express.bodyParser());
// app.use(app.router);
// app.get("/",function(req,res){
//   res.send("i am from / GET req");
// //
// // });
// // app.get("/form",function(req,res){
// //   res.sendFile("./form.html");
// //
// // });
// // app.post("/index.html",function(req,res){
// // var username=req.body.username;
// // var password=req.body.password;
// // var id=req.body.id;
// // res.send(`Username: ${username} Password: ${password} Id ${id}`)
//  });
// http.createServer(app).listen(3000);



// var express        =         require("express");
// var bodyParser     =         require("body-parser");
// var app            =         express();
//
// app.use(bodyParser.urlencoded({ extended: false }));
// app.use(bodyParser.json());
//
// app.get('/',function(req,res){
//   res.sendfile("index.html");
// });
// app.post('/login',function(req,res){
//   var user_name=req.body.user;
//   var password=req.body.password;
//   console.log("User name = "+user_name+", password is "+password);
//   res.end("yes");
// });
// app.listen(3000,function(){
//   console.log("Started on PORT 3000");
// })
// var express = require("express");
// var myParser = require("body-parser");
// var app = express();
//
//   app.use(myParser.urlencoded({extended : true}));
//   app.post("/index", function(request, response) {
//        saveRegistrationData(request); //This is what happens when a POST request is sent to /registeruser
//        res.send(`Username: ${username} Password: ${password} `);
//  });
// app.listen(3000);
