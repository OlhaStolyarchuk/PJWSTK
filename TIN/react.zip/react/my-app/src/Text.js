import React, { Component } from 'react';


class Text extends Component {
  render(){
    return <span> {this.props.text}</span>
  }
}
  export default Text;
