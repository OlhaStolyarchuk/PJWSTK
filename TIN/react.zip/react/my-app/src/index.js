import React from 'react';
import { render } from 'react-dom';
import ReactDOM from 'react-dom';
import './index.css';
import'./Formularz.css'
import App from './App';
import Text from './Text'
import Formularz from './Formularz'
//ReactDOM.render(<App name="Olya" sur="Stolyarchuk" id="s14988" />, document.getElementById('root'));
//ReactDOM.render(<Text text="Warsaw (Polish: Warszawa [varˈʂava] (About this soundlisten); see also other names) is the capital and largest city of Poland. The metropolis stands on the Vistula River in east-central Poland and its population is officially estimated at 1.765 million residents within a greater metropolitan area of 3.1 million residents,[4] which makes Warsaw the 8th most-populous capital city in the European Union. The city limits cover 516.9 square kilometres (199.6 sq mi), while the metropolitan area covers 6,100.43 square kilometres (2,355.39 sq mi).[5] Warsaw is an alpha global city, a major international tourist destination, and a significant cultural, political and economic hub. Its historical Old Town was designated a UNESCO World Heritage Site."/>, document.getElementById('root'));
// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: http://bit.ly/CRA-PWA
const View = () => (
  <div>
    <Formularz/>
  </div>
);
render(<View />, document.getElementById('root'));
