var wartosc = 10; //prompt('Wpisz wartosc', '');

console.log(typ(wartosc));

function typ(num) {
    return typeof(num);
}
// czy jest roznica miedzy "" a ''?
// czy jest mozliwosc sprawdzenia liczby przez prompt?
