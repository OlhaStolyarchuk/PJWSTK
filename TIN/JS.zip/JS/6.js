var liczba = prompt('Wpisz liczbe', '');
console.log('%cWpisano:', 'color: green');
console.log(liczba);
console.log('%cCzy to jest liczba pierwsza?' , 'color: green');
console.log(isPrime(liczba));

function isPrime(num) {
    if(num < 2) return false;
    for (var i = 2; i < num; i++) {
        if(num % i == 0)
            return false;
    }
    return true;
}