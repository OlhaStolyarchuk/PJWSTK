var ciag = prompt('Wpisz ciag znakow', '');
console.log('%cWpisano:', 'color: green');
console.log(ciag);
console.log('%cCzy jest palindromem?', 'color:green');
console.log(pal(ciag));

function pal(n) {
    var re = /[^A-Za-z0-9]/g;
    n = n.toLowerCase().replace(re, '');
    var len = n.length;
    for (var i = 0; i < len/2; i++) {
        if (n[i] !== n[len - 1 - i]) {
            return false;
        }
    }
        return true;
}