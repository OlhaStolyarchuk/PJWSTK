
var liczba = prompt('Wpisz pierwsza liczbe', '');
var wynik = function(x) {
    var res=x;
    var tmp = x;
    while(tmp != 1){
        res=res*(tmp-1);
        tmp -=1;
    }
    return res;
}
console.log(wynik(liczba) + ' (function expression)');
//--------------------------
var liczba = prompt('Wpisz druga liczbe ', '');
console.log(wynik(liczba) + ' (function declaration)');
function wynik(x) {
    var res=x;
    var tmp = x;
    while(tmp != 1){
        res=res*(tmp-1);
        tmp -=1;
    }
    return res;
}