var tablica = new Array('Marcin', 'Ania', 'Agnieszka', 'Łukasz');


function longestWordinArray () {
   var najdluzsze = '';

    for (var i = 0; i < tablica.length; i++) {
      if (tablica[i].length > najdluzsze.length) {

        najdluzsze = tablica[i];
      }
    }
    console.log(najdluzsze);

}

longestWordinArray();
