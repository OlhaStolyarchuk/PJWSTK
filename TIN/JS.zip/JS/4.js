var ciag = prompt('Wpisz ciag znakow', '');
console.log('%cWpisano:', 'color: green');
console.log(ciag);
console.log('%cW kolejnosci alfabetycznej: ', 'color:green');
console.log(abc(ciag));

function abc(n) {
    var a = n.split("").sort();
    var result = '';
    for(var i = 0; i < a.length; i++){
        result+=a[i];
    }
    return result;
}