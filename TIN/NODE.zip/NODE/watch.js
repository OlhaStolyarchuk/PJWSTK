const fs = require('fs');

fs.watch('/Users/olya/Desktop', 'utf8', (eventType, filename) => {
  if(eventType == 'change'){
    fs.readFile(`/Users/olya/Desktop${filename}`, (err, data) => {
      if(err){
        console.log(err);
      }else{
        console.log(`${filename}: ${data.toString('utf8')}`);
      }
    });
  }
});
