let http = require('http');
let url = require('url');

var server = http.createServer(function (request, response) {
    let operation = url.parse(request.url).pathname;
    let queryData = url.parse(request.url, true).query;
    let result = 0;
    let znak = '';
    let isCorrect = false;
    if('param1' in queryData && 'param2' in queryData){
      if(parseFloat((queryData.param1) && parseFloat(queryData.param2)) || (queryData.param1 == '0' || queryData.param2=='0')){
       switch (operation) {
         case '/add':
         isCorrect = true;
         znak = '+';
         result = parseFloat(queryData.param1) + parseFloat(queryData.param2);
         break;
         case '/sub':
         isCorrect = true;
         znak = '-';
         result = parseFloat(queryData.param1) - parseFloat(queryData.param2);
         break;
         case '/mul':
         isCorrect = true;
         znak = '*';
         result = parseFloat(queryData.param1) * parseFloat(queryData.param2);
         break;
         case '/div':
         isCorrect = true;
         znak = '/';
         result = parseFloat(queryData.param1) / parseFloat(queryData.param2);
         break;
         default:
           result = 'niepoprawny url adress';
      }
        if(isCorrect){
          response.end(queryData.param1 + znak + queryData.param2 + '=' + result);
        }else{
          response.end(result);
        }
      }else{
        response.end('to nie jest liczba');
      }

    }else{
      response.end('potrzebuje 2 parametry,dales jedna albo w ogole zadna');
    }

});

server.listen(3000);
