const express = require("express");
const session = require('express-session');
const path = require('path');

const router = require('./src/router');
const app = express();

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(session({
	secret: 'SecretToken',
	resave: true,
	saveUninitialized: true
}));

app.use(router);

app.use(function(err, req, res, next) {
	res.locals.message = err.message;
	res.locals.error = err;
	console.log(err);
	res.status(err.status || 500);
	res.render('error');
});

app.listen(3000);
