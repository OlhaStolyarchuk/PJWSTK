///pokazujemy w tym pliku jaki controler odpowoiada za jaku link
const express = require('express');
const router = express.Router();
const ctrl = require('../controller');

router.get('/', ctrl.indexGet);
router.get('/form', ctrl.indexForm);

router.post('/searchForm', ctrl.searchFormPost);

router.get('/city', ctrl.cityGet);
router.get('/city/all', ctrl.cityAll);
router.post('/city/add', ctrl.cityAddPost);
router.post('/city/delete', ctrl.cityDeletePost);
router.post('/city/edit', ctrl.cityEditPost);

router.get('/mode', ctrl.modeGet);
router.get('/mode/all', ctrl.modeAll);
router.post('/mode/add', ctrl.modeAddPost);
router.post('/mode/delete', ctrl.modeDeletePost);
router.post('/mode/edit', ctrl.modeEditPost);

router.get('/field', ctrl.fieldGet);
router.get('/field/all', ctrl.fieldAll);
router.post('/field/add', ctrl.fieldAddPost);
router.post('/field/delete', ctrl.fieldDeletePost);
router.post('/field/edit', ctrl.fieldEditPost);

router.get('/studies', ctrl.studiesGet);
router.get('/studies/all', ctrl.studiesAll);
router.post('/studies/add', ctrl.studiesAddPost);
router.post('/studies/delete', ctrl.studiesDeletePost);

router.get('/university', ctrl.universityGet);
router.get('/university/all', ctrl.universityAll);
router.post('/university/add', ctrl.universityAddPost);
router.post('/university/delete', ctrl.universityDeletePost);
router.post('/university/edit', ctrl.universityEditPost);

router.post('/registration', ctrl.registrationPost);

router.post('/login', ctrl.loginPost);
router.post('/logout', ctrl.logoutPost);

module.exports = router;
