const sqlite3 = require('sqlite3').verbose();

const CON = function(){

  var db = new sqlite3.Database('./src/database.db', (err) => {
    if (err){
      return console.error(err.message);
    }
  });
  db.getAsync = function (sql) {
    var that = this;
    return new Promise(function (resolve, reject) {
        that.get(sql, function (err, row) {
            if (err)
                reject(err);
            else
                resolve(row);
        });
    });
  };

  return db;

};

module.exports.con = CON;
