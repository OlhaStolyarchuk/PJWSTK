const db = require('../db').con();
const md5 = require('md5');//dla szyfrowania Password

//tutaj stworzylismy object module.exports.loginPost(nazwa) w ktory pomiescilismy funkcje
module.exports.loginPost = function(req, res){

  if(req.session && req.session.loggedin){
    res.render('404');
    return;
  }

  var email = req.body.email;
  var password = req.body.psw;
  //sprawdza i wyzuca wszystkie spacji
  if (email && email.replace(/\s/g, "").length && password) {                             //limit1=zeby wrocilo tylko 1 objekt
    db.all(`SELECT * FROM Student WHERE Email = '${email}' AND Password = '${md5(password)}' LIMIT 1`, function(err, results) {
      if(err){
        res.render('error', {session: req.session});
        return;
      }
      if (results.length) {
        req.session.loggedin = true;
        req.session.username = results[0].Name;
        req.session.save();
        res.redirect('/form');
      } else {
        res.redirect('/#Login');
      }
      res.end();
    });
  } else {
    res.redirect('/#Login');
    res.end();
  }
};

module.exports.logoutPost = function(req, res) {

  if(!req.session || !req.session.loggedin){
    res.render('404');
    return;
  }

  if (req.session) {
    req.session.loggedin = false;
    req.session.username = '';
    req.session.userId = -1;
    req.session.userRole = '';

    req.session.destroy(function(err) {
      if(err) {
        res.render('error', {session: req.session});
        return;

      } else {
        res.redirect('/');
      }
    });
  }
};
