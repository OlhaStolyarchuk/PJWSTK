const db = require('../db').con();
// цілий файл виконує функцію едитовання збоку поля city
module.exports.get = function (req, res) {

  var session = req.session;

  if(!session || !session.loggedin){
    res.render('404');
    return;
  }

  var data = req.body;

  db.all(`SELECT * FROM City`, function (err, citiesRes) {
    if (err) {
      res.render('error');
      return;
    }

    res.render('editCity', {cities: citiesRes});
  });

};

module.exports.all = function (req, res) {

  var session = req.session;

  if(!session || !session.loggedin){
    res.render('404');
    return;
  }

  db.all(`SELECT * FROM City`, function (err, queryRes) {
    if (err) {
      res.render('error');
      return;
    }

    res.send(JSON.stringify(queryRes));
  });
};

module.exports.addPost = function (req, res) {

  var session = req.session;

  if(!session || !session.loggedin){
    res.render('404');
    return;
  }

  var data = req.body;
                                                  //sprawdza i wyzuca wszystkie spacji
  if(!data.NewCityName.length || !data.NewCityName.replace(/\s/g, "").length){
    res.render('404');
    return;
  }

  db.all(`INSERT INTO City (NameOfCity) VALUES ('${data.NewCityName}')`, function (err, citiesRes) {
    if (err) {
      res.render('error');
      return;
    }

    res.redirect('/city');
  });
};

module.exports.deletePost = function (req, res) {

  var session = req.session;

  if(!session || !session.loggedin){
    res.render('404');
    return;
  }

  var data = req.body;

  if(!data.cityId){
    res.render('404');
    return;
  }

  db.all(`DELETE FROM City WHERE IdCity = ${data.cityId}`, function (err, citiesRes) {
    if (err) {
      res.render('error');
      return;
    }
    res.redirect('/city');
  });
};

module.exports.editPost = function (req, res) {

  var session = req.session;

  if(!session || !session.loggedin){
    res.render('404');
    return;
  }

  var data = req.body;

  if(!data.cityId || !data.CityName.length || !data.CityName.replace(/\s/g, "").length){
    res.render('404');
    return;
  }

  db.all(`UPDATE City SET NameOfCity = '${data.CityName}' WHERE IdCity = ${data.cityId}`, function (err, citiesRes) {
    if (err) {
      res.render('error');
      return;
    }
    res.redirect('/city');
  });
};
