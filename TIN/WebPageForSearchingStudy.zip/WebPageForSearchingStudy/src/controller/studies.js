const db = require('../db').con();

module.exports.get = function (req, res) {

  var session = req.session;

  if(!session || !session.loggedin){
    res.render('404');
    return;
  }

  db.all(`SELECT * FROM Studies`, function (err, studiesRes) {
    if (err) {
      res.render('error');
      return;
    }

    db.all(`SELECT f.IdFieldOfStudy, f.Payment, f.IdUniversity, ((select Name from University where University.IdUniversity = f.IdUniversity) || ' - ' || f.NameOfField) AS Name FROM Field AS f`, function (err, fieldsRes) {
      if (err) {
        res.render('error');
        return;
      }

      db.all(`SELECT * FROM Mode`, function (err, modesRes) {
        if (err) {
          res.render('error');
          return;
        }

        res.render('editStudies', {studies: studiesRes, fields: fieldsRes, modes: modesRes});
      });
    });
  });
};

module.exports.all = function (req, res) {

  var session = req.session;

  if(!session || !session.loggedin){
    res.render('404');
    return;
  }

  db.all(`SELECT s.IdStudies, s.IdMode, (select NameOfMode from Mode where Mode.IdMode = s.IdMode) AS ModeName, `
  +`s.IdFieldOfStudy, (select ((select Name from University where University.IdUniversity = f.IdUniversity) || ' - ' || NameOfField) AS University from Field as f where f.IdFieldOfStudy = s.IdFieldOfStudy) AS Field_University FROM Studies AS s`, function (err, queryRes) {
    if (err) {
      res.render('error');
      return;
    }

    res.send(JSON.stringify(queryRes));
  });
};

module.exports.addPost = async function (req, res) {

  var session = req.session;

  if(!session || !session.loggedin){
    res.render('404');
    return;
  }

  var data = req.body;

  if(!data.fieldId || !data.modeId){
    res.render('404');
    return;
  }

  var dublicate = await db.getAsync(`SELECT * FROM Studies WHERE IdFieldOfStudy = ${data.fieldId} AND IdMode = ${data.modeId};`)
  .catch((err) => {
    res.render('error');
    return;
  });

  if(dublicate){
    res.render('error');
    return;
  }

  db.all(`INSERT INTO Studies (IdMode, IdFieldOfStudy) VALUES (${data.modeId}, ${data.fieldId})`, function (err, studiesRes) {
    if (err) {
      res.render('error');
      return;
    }

    res.redirect('/studies');
  });
};

module.exports.deletePost = function (req, res) {

  var session = req.session;

  if(!session || !session.loggedin){
    res.render('404');
    return;
  }

  var data = req.body;

  if(!data.studyId){
    res.render('404');
    return;
  }

  db.all(`DELETE FROM Studies WHERE IdStudies = ${data.studyId}`, function (err, studiesRes) {
    if (err) {
      res.render('error');
      return;
    }
    res.redirect('/studies');
  });
};
