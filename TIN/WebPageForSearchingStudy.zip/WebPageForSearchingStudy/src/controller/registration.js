const db = require('../db').con();
const md5 = require('md5');//dla szyfrowania Password

module.exports.post = function (req, res) {

  var session = req.session;
//pomaga robic sprawdzenie czy pola jest puste czy user jest zalogowany
  if(session && session.loggedin){
    res.render('404');
    return;
  }

  var user = req.body;

//sprawdza czy taki email istnieje, jesli nie to zrób regestracje nanovo
  db.all(`SELECT * FROM Student WHERE Email = '${user.email}' LIMIT 1`, function (err, resUser) {
//sprawdzamy czy pole nie jest puste|| czy nie ma spacji w email||czy nie ma  spacji w password
    if(err || resUser.length || (/\s/.test(user.email)) || (/\s/.test(user.psw))){
      res.redirect('/');
      return;
    }

    db.all(`INSERT INTO Student (Name, Surname, Password, Email) VALUES ('${user.Name}', '${user.surname}', '${md5(user.psw)}', '${user.email}')`, function (err, insertRes) {

      if(err){
        res.render('error');
        return;
      }

      res.redirect('/#Login');
    });
  });
};
