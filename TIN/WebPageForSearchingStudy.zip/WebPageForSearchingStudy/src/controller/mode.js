const db = require('../db').con();

module.exports.get = function (req, res) {

  var session = req.session;

  if(!session || !session.loggedin){
    res.render('404');
    return;
  }

  var data = req.body;

  db.all(`SELECT * FROM Mode`, function (err, modesRes) {
    if (err) {
      res.render('error');
      return;
    }

    res.render('editMode', {modes: modesRes});
  });
};

module.exports.all = function (req, res) {

  var session = req.session;

  if(!session || !session.loggedin){
    res.render('404');
    return;
  }

  db.all(`SELECT * FROM Mode`, function (err, queryRes) {
    if (err) {
      res.render('error');
      return;
    }

    res.send(JSON.stringify(queryRes));
  });
};

module.exports.addPost = function (req, res) {

  var session = req.session;

  if(!session || !session.loggedin){
    res.render('404');
    return;
  }

  var data = req.body;

  if(!data.NewModeName.length || !data.NewModeName.replace(/\s/g, "").length){
    res.render('404');
    return;
  }

  db.all(`INSERT INTO Mode (NameOfMode) VALUES ('${data.NewModeName}')`, function (err, modesRes) {
    if (err) {
      res.render('error');
      return;
    }

    res.redirect('/mode');
  });
};

module.exports.deletePost = function (req, res) {

  var session = req.session;

  if(!session || !session.loggedin){
    res.render('404');
    return;
  }

  var data = req.body;

  if(!data.modeId){
    res.render('404');
    return;
  }

  db.all(`DELETE FROM Mode WHERE IdMode = ${data.modeId}`, function (err, modesRes) {
    if (err) {
      res.render('error');
      return;
    }
    res.redirect('/mode');
  });
};

module.exports.editPost = function (req, res) {

  var session = req.session;

  if(!session || !session.loggedin){
    res.render('404');
    return;
  }

  var data = req.body;

  if(!data.modeId || !data.ModeName.length || !data.ModeName.replace(/\s/g, "").length){
    res.render('404');
    return;
  }

  db.all(`UPDATE Mode SET NameOfMode = '${data.ModeName}' WHERE IdMode = ${data.modeId}`, function (err, modesRes) {
    if (err) {
      res.render('error');
      return;
    }
    res.redirect('/mode');
  });
};
