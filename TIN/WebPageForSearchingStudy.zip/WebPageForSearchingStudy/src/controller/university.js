const db = require('../db').con();

module.exports.get = function (req, res) {

  var session = req.session;

  if(!session || !session.loggedin){
    res.render('404');
    return;
  }

  var data = req.body;

  db.all(`SELECT * FROM University`, function (err, universitiesRes) {
    if (err) {
      res.render('error');
      return;
    }

    db.all(`SELECT * FROM City`, function (err, citiesRes) {
      if (err) {
        res.render('error');
        return;
      }

      res.render('editUniversity', {cities: citiesRes, universities: universitiesRes});
    });
  });
};

module.exports.all = function (req, res) {

  var session = req.session;

  if(!session || !session.loggedin){
    res.render('404');
    return;
  }

  db.all(`SELECT IdUniversity, IdCity, Name, Street, ('<a href="' || WebPage || '">' || WebPage || '</a>') AS WebPage FROM University`, function (err, queryRes) {
    if (err) {
      res.render('error');
      return;
    }

    res.send(JSON.stringify(queryRes));
  });
};

module.exports.addPost = function (req, res) {

  var session = req.session;

  if(!session || !session.loggedin){
    res.render('404');
    return;
  }

  var data = req.body;

  if(!data.NewUniversityName.replace(/\s/g, "").length || !data.NewUniversityStreet.replace(/\s/g, "").length || !data.NewUniversityWebPage.replace(/\s/g, "").length || !data.NewUniversityCityId){
    res.render('404');
    return;
  }

  db.all(`INSERT INTO University (Name, Street, WebPage, IdCity) VALUES ('${data.NewUniversityName}', '${data.NewUniversityStreet}', '${data.NewUniversityWebPage}', ${data.NewUniversityCityId})`, function (err, universRes) {
    if (err) {
      res.render('error');
      return;
    }

    res.redirect('/university');
  });
};

module.exports.deletePost = function (req, res) {

  var session = req.session;

  if(!session || !session.loggedin){
    res.render('404');
    return;
  }

  var data = req.body;

  if(!data.universityId){
    res.render('404');
    return;
  }

  db.all(`DELETE FROM University WHERE IdUniversity = ${data.universityId}`, function (err, universityRes) {
    if (err) {
      res.render('error');
      return;
    }
    res.redirect('/university');
  });
};

module.exports.editPost = async function (req, res) {

  var session = req.session;

  if(!session || !session.loggedin){
    res.render('404');
    return;
  }

  var data = req.body;

  if(!data.universityId){
    res.render('404');
    return;
  }

  var UniversityOne = await db.getAsync(`SELECT * FROM University WHERE IdUniversity = ${data.universityId} LIMIT 1;`).then((row) => {
    if(!row){
      res.render('error');
      return;
    }
    return row;
  }).catch((err) => {
    res.render('error');
    return;
  });

  if(data.universityName && data.universityName.replace(/\s/g, "").length && data.universityName != UniversityOne.Name){
    await db.getAsync(`UPDATE University SET Name = '${data.universityName}' WHERE IdUniversity = ${data.universityId};`)
    .catch((err) => {
      res.render('error');
      return;
    });
  }

  if(data.universityStreet && data.universityStreet.replace(/\s/g, "").length && data.universityStreet != UniversityOne.Street){
    await db.getAsync(`UPDATE University SET Street = '${data.universityStreet}' WHERE IdUniversity = ${data.universityId};`)
    .catch((err) => {
      res.render('error');
      return;
    });
  }

  if(data.universityWebPage && data.universityWebPage.replace(/\s/g, "").length && data.universityWebPage != UniversityOne.WebPage){
    await db.getAsync(`UPDATE University SET WebPage = '${data.universityWebPage}' WHERE IdUniversity = ${data.universityId};`)
    .catch((err) => {
      res.render('error');
      return;
    });
  }

  if(data.universityCity && data.universityCity != UniversityOne.IdCity){
    await db.getAsync(`UPDATE University SET IdCity = ${data.universityCity} WHERE IdUniversity = ${data.universityId};`)
    .catch((err) => {
      res.render('error');
      return;
    });
  }

  res.redirect('/university');

};
