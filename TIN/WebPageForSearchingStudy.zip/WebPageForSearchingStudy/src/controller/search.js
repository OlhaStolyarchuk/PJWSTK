const db = require('../db').con();
// search.js-шукає результат по заданим 3 полях на сторінці /form
module.exports.searchFormPost = function (req, res) {

  var data = req.body;

  db.all(`SELECT * FROM University u, City c, Field f, Studies s, Mode m `
    +`WHERE c.IdCity=u.IdCity AND u.IdUniversity=f.IdUniversity AND f.IdFieldOfStudy=s.IdFieldOfStudy `
    +`AND s.IdMode = m.IdMode AND c.IdCity = ${data.c} AND f.IdFieldOfStudy = ${data.f} AND m.IdMode = ${data.m}`, function (err, rows) {
      if (err) {
        res.render('error');
        return;
      }

      res.send(JSON.stringify(rows));
    });
  };
