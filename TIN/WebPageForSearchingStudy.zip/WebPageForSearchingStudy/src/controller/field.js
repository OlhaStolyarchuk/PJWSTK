const db = require('../db').con();

module.exports.get = function (req, res) {

  var session = req.session;

  if(!session || !session.loggedin){
    res.render('404');
    return;
  }

  var data = req.body;

  db.all(`SELECT * FROM Field`, function (err, fieldsRes) {
    if (err) {
      res.render('error');
      return;
    }

    db.all(`SELECT * FROM University`, function (err, universitiesRes) {
      if (err) {
        res.render('error');
        return;
      }

      res.render('editField', {fields: fieldsRes, universities: universitiesRes});
    });
  });
};

module.exports.all = function (req, res) {

  var session = req.session;

  if(!session || !session.loggedin){
    res.render('404');
    return;
  }

  db.all(`SELECT f.IdFieldOfStudy, f.IdUniversity, (select Name from University where IdUniversity = f.IdUniversity) as University, f.NameOfField, f.Payment FROM Field AS f`, function (err, queryRes) {
    if (err) {
      res.render('error');
      return;
    }

    res.send(JSON.stringify(queryRes));
  });
};

module.exports.addPost = function (req, res) {

  var session = req.session;

  if(!session || !session.loggedin){
    res.render('404');
    return;
  }

  var data = req.body;
     //sprawdza i wyzuca wszystkie spacji
  if(!data.NewFieldName.replace(/\s/g, "").length || !data.FieldPayment.replace(/\s/g, "").length || !data.fieldUniversity){
    res.render('404');
    return;
  }

  db.all(`INSERT INTO Field (NameOfField, IdUniversity, Payment) VALUES ('${data.NewFieldName}', ${data.fieldUniversity}, '${data.FieldPayment}')`, function (err, fieldsRes) {
    if (err) {
      res.render('error');
      return;
    }

    res.redirect('/field');
  });
};

module.exports.deletePost = function (req, res) {

  var session = req.session;

  if(!session || !session.loggedin){
    res.render('404');
    return;
  }

  var data = req.body;

  if(!data.fieldId){
    res.render('404');
    return;
  }

  db.all(`DELETE FROM Field WHERE IdFieldOfStudy = ${data.fieldId}`, function (err, fieldsRes) {
    if (err) {
      res.render('error');
      return;
    }
    res.redirect('/field');
  });
};

module.exports.editPost = async function (req, res) {

  var session = req.session;

  if(!session || !session.loggedin){
    res.render('404');
    return;
  }

  var data = req.body;

  if(!data.fieldId){
    res.render('404');
    return;
  }

  var fieldOne = await db.getAsync(`SELECT * FROM Field WHERE IdFieldOfStudy = ${data.fieldId} LIMIT 1;`).then((row) => {
    if(!row){
      res.render('error');
      return;
    }
    return row;
  }).catch((err) => {
    res.render('error');
    return;
  });

  if(data.fieldUniversity && data.fieldUniversity != fieldOne.IdUniversity){
    await db.getAsync(`UPDATE Field SET IdUniversity = ${data.fieldUniversity} WHERE IdFieldOfStudy = ${data.fieldId};`)
    .catch((err) => {
      res.render('error');
      return;
    });
  }

  if(data.FieldName && data.FieldName.replace(/\s/g, "").length && data.FieldName != fieldOne.NameOfField){
    await db.getAsync(`UPDATE Field SET NameOfField = '${data.FieldName}' WHERE IdFieldOfStudy = ${data.fieldId};`)
    .catch((err) => {
      res.render('error');
      return;
    });
  }

  if(data.FieldPayment && data.FieldPayment.replace(/\s/g, "").length && data.FieldPayment != fieldOne.Payment){
    await db.getAsync(`UPDATE Field SET Payment = '${data.FieldPayment}' WHERE IdFieldOfStudy = ${data.fieldId};`)
    .catch((err) => {
      res.render('error');
      return;
    });
  }

  res.redirect('/field');

};
