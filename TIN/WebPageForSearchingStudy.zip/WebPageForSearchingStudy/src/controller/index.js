const mainCntrl = require('../controller/main');
const searchCntrl = require('../controller/search');
const cityCntrl = require('../controller/city');
const modeCntrl = require('../controller/mode');
const fieldCntrl = require('../controller/field');
const studiesCntrl = require('../controller/studies');
const universityCntrl = require('../controller/university');
const registrationCntrl = require('../controller/registration');
const loginCntrl = require('../controller/login');

module.exports.indexGet = mainCntrl.get;
module.exports.indexForm = mainCntrl.getForm;

module.exports.searchFormPost = searchCntrl.searchFormPost;

module.exports.cityGet = cityCntrl.get;
module.exports.cityAll = cityCntrl.all;
module.exports.cityAddPost = cityCntrl.addPost;
module.exports.cityDeletePost = cityCntrl.deletePost;
module.exports.cityEditPost = cityCntrl.editPost;

module.exports.modeGet = modeCntrl.get;
module.exports.modeAll = modeCntrl.all;
module.exports.modeAddPost = modeCntrl.addPost;
module.exports.modeDeletePost = modeCntrl.deletePost;
module.exports.modeEditPost = modeCntrl.editPost;

module.exports.fieldGet = fieldCntrl.get;
module.exports.fieldAll = fieldCntrl.all;
module.exports.fieldAddPost = fieldCntrl.addPost;
module.exports.fieldDeletePost = fieldCntrl.deletePost;
module.exports.fieldEditPost = fieldCntrl.editPost;

module.exports.studiesGet = studiesCntrl.get;
module.exports.studiesAll = studiesCntrl.all;
module.exports.studiesAddPost = studiesCntrl.addPost;
module.exports.studiesDeletePost = studiesCntrl.deletePost;

module.exports.universityGet = universityCntrl.get;
module.exports.universityAll = universityCntrl.all;
module.exports.universityAddPost = universityCntrl.addPost;
module.exports.universityDeletePost = universityCntrl.deletePost;
module.exports.universityEditPost = universityCntrl.editPost;

module.exports.registrationPost = registrationCntrl.post;

module.exports.loginPost = loginCntrl.loginPost;
module.exports.logoutPost = loginCntrl.logoutPost;
