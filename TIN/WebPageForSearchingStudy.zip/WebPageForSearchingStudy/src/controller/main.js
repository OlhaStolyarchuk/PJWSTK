//ten fail odpowiada za to ze przy ladowania strony jest request na database i tworzy strone
const db = require('../db').con();

module.exports.get = function(req,res){

  session = req.session;

  if(session && session.loggedin){
    res.redirect('/form');
    return;
  }

  res.render('main', {session: session});

};

module.exports.getForm = function(req,res){

  db.all(`SELECT IdCity, NameOfCity FROM City`, function (err, citiesRes) {
    if (err) {
      res.render('error');
      return;
    }

    db.all(`SELECT IdMode, NameOfMode FROM Mode`, function (err, modesRes) {
      if (err) {
        res.render('error');
        return;
      }

      db.all(`SELECT IdFieldOfStudy, NameOfField FROM Field`, function (err, fieldsRes) {
        if (err) {
          res.render('error');
          return;
        }

        res.render('form', {cities: citiesRes, modes: modesRes, fields: fieldsRes, session: req.session});
      });
    });
  });
};
