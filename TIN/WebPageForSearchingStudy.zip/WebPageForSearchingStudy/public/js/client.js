function addToTable(data){

  var json=JSON.parse(data);

  let tbl='<table class="table-data table table-bordered" cellpadding="2" cellspacing="2" border="1"><tr><td>NameOfUniversity</td><td>Street</td><td>WebPage</td><td>Payment</td></tr>';

  for(var s of json) {
    tbl+='<tr><td>'+s.Name+'</td><td>'+s.Street+'</td><td>' + '<a href="' + s.WebPage + '">' + s.WebPage + '</a>' + '</td><td>'+s.Payment+'</td><tr>';
  }
  tbl+='</table>';
  document.getElementById("data").innerHTML=tbl;
}

function getDataFromInputs(){
  var values = {};

  values.c = document.getElementById("c").value;
  values.m = document.getElementById("m").value;
  values.f = document.getElementById("f").value;

  return values;
}

$(document).ready( function () {
  $('#submitbuttom').click( function () {
    $.ajax({
      type: "POST",
      url: "/searchForm",
      data: getDataFromInputs(),
      success: function(data, textStatus) {
        if(textStatus == 'success')
        addToTable(data);
      }
    });
  });

  $('#viewTableBtn').click( function () {
    $("#data-table tr").remove();
    $("#data-table th").remove();
    var type = window.location.pathname.split("/")[1];
    $.ajax({
      type: "GET",
      url: "/" + type + "/all",
      success: function(data, textStatus) {
        if(textStatus == 'success')
        buildHtmlTable('#data-table', JSON.parse(data));
      }
    });
  });
});

function buildHtmlTable(selector, data) {
  var columns = addAllColumnHeaders(data, selector);

  for (var i = 0; i < data.length; i++) {
    var row$ = $('<tr/>');
    for (var colIndex = 0; colIndex < columns.length; colIndex++) {
      var cellValue = data[i][columns[colIndex]];
      if (cellValue == null) cellValue = "";
      row$.append($('<td/>').html(cellValue));
    }
    $(selector).append(row$);
  }
}

function addAllColumnHeaders(data, selector) {
  var columnSet = [];
  var headerTr$ = $('<tr/>');

  for (var i = 0; i < data.length; i++) {
    var rowHash = data[i];
    for (var key in rowHash) {
      if ($.inArray(key, columnSet) == -1) {
        columnSet.push(key);
        headerTr$.append($('<th/>').html(key));
      }
    }
  }
  $(selector).append(headerTr$);

  return columnSet;
}
