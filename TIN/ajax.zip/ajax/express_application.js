const express = require('express');
const bodyParser = require('body-parser');

const app = express();
app.use(express.json());
app.use(bodyParser.urlencoded({
    extended: true
}));
app.use(bodyParser.json());
app.listen(3000);

app.post('/jsondata', function(req, res) {
   const first_number = parseFloat(req.body.first_number);
   const operation = req.body.operation;
   const second_number = parseFloat(req.body.second_number);
  let znak = '';
  let result="";
  let isCorrect = false;
//  res.send("Proszę podać liczby jako string");
//}
if((first_number && second_number || first_number == 0 || second_number == 0)){
  switch (operation) {
    case "add":
     isCorrect = true;
       znak = '+';
       result=first_number + second_number;
      break;
      case "sub":
       isCorrect = true;
         znak = '-';
         result=first_number - second_number;
        break;
        case "mul":
         isCorrect = true;
           znak = '*';
           result=first_number * second_number;
          break;
          case "div":
          if(second_number == 0){
          result="it's not allow divide y zero";
          }
           isCorrect = true;
             znak = '/';

             result=first_number / second_number;
            break;
    default:
      result = 'niepoprawna liczba';
  }
  if(isCorrect){
  res.setHeader('Content-type','application/json; charset=utf-8');
  res.send(JSON.stringify({"result":result}));
  console.log(JSON.stringify({"result":result}));


}else{
  response.send('potrzebuje 2 parametry,dalej jedna albo w ogole zadna');
}
}
});
