function ajax(){
  let request = window.XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
  request.onreadystatechange = function() {
  if(request.readyState == 4 && request.status == 200) {
    handler(request);
  }
  };
  request.open('POST', '/jsondata', true);
  request.setRequestHeader('Content-type', 'application/json; charset=utf-8');
  request.send(getDataFromInputs());
}
function getDataFromInputs(){
  let f = document.querySelector("#first").value;
  let s = document.querySelector("#second").value;
  let op = document.querySelector("#operation").value;
  return JSON.stringify({
  first:f,
  second:s,
  operation: op
  });
}
function handler(request){
  let json = JSON.parse(request.responseText);
  document.querySelector("#result").innerText = "Result: " + json["result"];
}
document.querySelector('#sendButton').onclick = function(){
  ajax();
};
