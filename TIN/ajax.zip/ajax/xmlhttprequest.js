let express = require('express');
let app = express();
app.use(express.json());
let bodyParser = require('body-parser');
app.use(bodyParser.json());
var path = require('path');
var appDir = path.dirname(require.main.filename);
app.use(express.static(__dirname + "/public"));

app.get('/', function(req, res){
  res.sendFile(__dirname+ '/form.html');
});

app.post('/jsondata', function(req, res){
  console.log(req.body);
  res.send(getResult(req.body["first"], req.body["second"], req.body["operation"]));
});

function getResult(f, s, operation){
  let first_number=parseFloat(f);
  let second_number=parseFloat(s);
  let json = "";
  if((first_number && second_number) || (first_number == 0 || second_number == 0)){
    switch(operation){
    case "+":
      json = {
        result: first_number+second_number
      };
      return JSON.stringify(json);
      break;
  case "-":
      json = {
        result: first_number - second_number
      };
      return JSON.stringify(json);
      break;
    case "*":
      json = {
        result: first_number*second_number
      };
      return JSON.stringify(json);
      break;
    case "/":
      if(second_number == 0){
        json = {
          result: "dividing by zero!"
        };
   }
        json = {
          result: first_number/second_number
        };

      return JSON.stringify(json);
    break;
  default:
    json = {
      result: "niepoprawny request"
    };
    return JSON.stringify(json);
  }
  }
}


app.listen(3000, function () {
  console.log('Listening on port 3000.....');
});
